﻿using System;
using System.Buffers;
using System.Buffers.Binary;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Threading;
using LibOrbisPkg.Util;

namespace LibOrbisPkg.PFS
{
  /// <summary>
  /// Provides XTS decryption on an IMemoryReader.
  /// PSVIETHOA STUDIO 2.1.0: rewritten for speed (one AES-NI ECB call per sector, 64-bit tweak doubling, no per-sector
  /// allocations, one bulk read per request) and made safe for concurrent readers (AES objects per thread).
  /// Output is identical to the original byte-wise implementation (IEEE 1619 XTS-AES-128, tweak = sector number LE).
  /// </summary>
  public class XtsDecryptReader : IMemoryReader
  {
    private readonly byte[] dataKey;
    private readonly byte[] tweakKey;
    /// <summary>Size of each XEX sector</summary>
    private readonly uint sectorSize;
    /// <summary>Sector at and after which the encryption is active</summary>
    private readonly uint cryptStartSector;
    private readonly IMemoryReader reader;
    private readonly ThreadLocal<(Aes Data, Aes Tweak)> aes;

    /// <summary>
    /// Creates an AES-XTS-128 stream.
    /// Reads will decrypt data.
    /// </summary>
    public XtsDecryptReader(
      IMemoryReader r,
      byte[] dataKey,
      byte[] tweakKey, uint startSector = 16, uint sectorSize = 0x1000)
    {
      cryptStartSector = startSector;
      this.sectorSize = sectorSize;
      this.dataKey = (byte[])dataKey.Clone();
      this.tweakKey = (byte[])tweakKey.Clone();
      reader = r;
      aes = new ThreadLocal<(Aes, Aes)>(() =>
      {
        var d = Aes.Create(); d.Key = this.dataKey;
        var t = Aes.Create(); t.Key = this.tweakKey;
        return (d, t);
      });
    }

    /// <summary>Decrypts one sector in place. <paramref name="masks"/> must hold at least sector.Length bytes.</summary>
    public static void DecryptSector(Aes data, Aes tweakCipher, Span<byte> sector, ulong sectorNum, Span<byte> masks)
    {
      Span<byte> t = stackalloc byte[16];
      BinaryPrimitives.WriteUInt64LittleEndian(t, sectorNum);
      BinaryPrimitives.WriteUInt64LittleEndian(t[8..], 0);
      tweakCipher.EncryptEcb(t, t, PaddingMode.None);
      ulong lo = BinaryPrimitives.ReadUInt64LittleEndian(t), hi = BinaryPrimitives.ReadUInt64LittleEndian(t[8..]);
      var m = MemoryMarshal.Cast<byte, ulong>(masks[..sector.Length]);
      for (int i = 0; i < m.Length; i += 2)
      {
        m[i] = lo; m[i + 1] = hi;                   // little-endian host (x64)
        ulong carry = hi >> 63;                     // tweak *= α in GF(2^128)
        hi = (hi << 1) | (lo >> 63);
        lo = (lo << 1) ^ (carry * 0x87UL);
      }
      var s = MemoryMarshal.Cast<byte, ulong>(sector);
      for (int i = 0; i < s.Length; i++) s[i] ^= m[i];
      data.DecryptEcb(sector, sector, PaddingMode.None);
      for (int i = 0; i < s.Length; i++) s[i] ^= m[i];
    }

    public void Read(long position, byte[] buffer, int offset, int count)
    {
      if (count <= 0) return;
      long first = position / sectorSize, lastSector = (position + count - 1) / sectorSize;
      int sectors = (int)(lastSector - first + 1);
      int ss = (int)sectorSize;
      // Bulk read in pieces of at most 8 MiB of sectors.
      int maxPerRead = Math.Max(1, (8 << 20) / ss);
      var raw = ArrayPool<byte>.Shared.Rent(Math.Min(sectors, maxPerRead) * ss);
      var masks = ArrayPool<byte>.Shared.Rent(ss);
      try
      {
        var (data, tweak) = aes.Value;
        long sector = first;
        int skip = (int)(position - first * sectorSize);
        while (count > 0)
        {
          int n = (int)Math.Min(maxPerRead, lastSector - sector + 1);
          reader.Read(sector * sectorSize, raw, 0, n * ss);
          for (int i = 0; i < n; i++)
            if (sector + i >= cryptStartSector)
              DecryptSector(data, tweak, raw.AsSpan(i * ss, ss), (ulong)(sector + i), masks);
          int take = Math.Min(n * ss - skip, count);
          Buffer.BlockCopy(raw, skip, buffer, offset, take);
          offset += take; count -= take; skip = 0;
          sector += n;
        }
      }
      finally
      {
        ArrayPool<byte>.Shared.Return(raw);
        ArrayPool<byte>.Shared.Return(masks);
      }
    }

    public void Dispose()
    {
      // We don't own the IMemoryReader, so do nothing.
    }
  }
}
